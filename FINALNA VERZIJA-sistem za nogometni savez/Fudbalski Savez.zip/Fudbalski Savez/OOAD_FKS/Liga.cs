﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public  class Liga
    {


        public int liga_id { get; set; }
        public int broj_klubova { get; set; }
        public DateTime pocetak { get; set; }
        public DateTime kraj { get; set; }
        public string naziv  { get; set; }
        

        public Liga (int broj,DateTime pocetak1,DateTime kraj1,string naziv1, int id=0)
        {
            broj_klubova=broj;
            pocetak=pocetak1;
            kraj=kraj1;
            naziv=naziv1;
            liga_id = id;
        }


        public Liga(Liga l)
        {
            broj_klubova = l.broj_klubova;
            pocetak = l.pocetak;
            kraj = l.kraj;
            naziv = l.naziv;
            liga_id = l.liga_id;
        }
        public Liga()
        {

        }


        public override string ToString()
         {
             return ("Liga : " + naziv + " " + Environment.NewLine + "broj klubova : " + broj_klubova + Environment.NewLine + "datum  pocetka: " + pocetak + Environment.NewLine + "datum kraja: " + kraj + Environment.NewLine);

         }
    }
}
