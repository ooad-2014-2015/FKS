﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public class Kolo
    {


        public int kolo_id { get; set; }
        public int redni_broj { get; set; }
        public int broj_utakmica { get; set; }
        public Liga liga { get; set; }
       

        public Kolo(int redni ,int broj , Liga l, int id=0)
        {
            redni_broj=redni;
            broj_utakmica=broj;
            liga=l;
            kolo_id = id;
        }

        public Kolo(Kolo k)
        {
            redni_broj = k.redni_broj;
            broj_utakmica = k.broj_utakmica;
            liga = k.liga;
            kolo_id = k.kolo_id;
        }

        public Kolo()
        {

        }


        public override string ToString()
{
 	return ("Redni broj kola : " + redni_broj + Environment.NewLine + "lige : " +  liga.naziv + Environment.NewLine);

}
    }
}
