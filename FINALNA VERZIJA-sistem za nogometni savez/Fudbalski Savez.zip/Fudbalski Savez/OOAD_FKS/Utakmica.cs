﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public class Utakmica
    {
        public int utakmica_id {get; set ;}
        public Klub domaci { get; set; }
        public Klub  gosti { get; set; }
        public int rezultat_gosti { get; set; }
        public int rezultat_domaci { get; set; }
        public string mjesto { get; set; }
        public string stadion { get; set; }
        public DateTime datum_odrzavanja { get; set; }
        public Kolo kolo { get; set; }
        public string glavni_sudija { get; set; }

        public Utakmica(Klub dom, Klub gos, int rez_dom, int rez_gos, string mjesto1, string stadion1, DateTime odrzavanje, Kolo k, string sudija,int id=0)
        {
            domaci = dom;
            gosti = gos;
            rezultat_domaci=rez_dom;
            rezultat_gosti=rez_gos;
            mjesto=mjesto1;
            stadion=stadion1;
            datum_odrzavanja=odrzavanje;
            kolo = k;
            glavni_sudija= sudija;
            utakmica_id=id;

        }
        public Utakmica(Utakmica u)
        {
            domaci = u.domaci;
            gosti = u.gosti;
            rezultat_domaci = u.rezultat_domaci;
            rezultat_gosti = u.rezultat_gosti;
            mjesto = u.mjesto;
            stadion = u.stadion;
            datum_odrzavanja = u.datum_odrzavanja;
            kolo = u.kolo;
            glavni_sudija = u.glavni_sudija;
            utakmica_id = u.utakmica_id;

        }

        public Utakmica ()
        {}

        public override string ToString()
{
 	 return ("Utakmicu igra : " +domaci.naziv + " protiv " + gosti.naziv +Environment.NewLine + " stadion :" + stadion + Environment.NewLine+" mjesto:"+ mjesto +Environment.NewLine + " datum odrzavanja:" +datum_odrzavanja+Environment.NewLine +" rezulata:" + rezultat_domaci.ToString() +" : " +rezultat_gosti.ToString() +Environment.NewLine +" kolo:" +kolo.broj_utakmica.ToString()+Environment.NewLine +" sudija:" +glavni_sudija+Environment.NewLine);
         
}

    }
}
