﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using OOAD_FKS;
using Baza;
using System.Threading;


namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for UnosIgraca.xaml
    /// </summary>
    public partial class UnosIgraca : Window
    {
        public Klub user;
        public UnosIgraca(Klub kor)
        {
            user = kor;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Int32 brojg = Convert.ToInt32(BrojGolovaTB.Text);
            Int32 broja = Convert.ToInt32(BrojAsistencijaTB.Text);
            Int32 brzutih = Convert.ToInt32(BrojZutihTB.Text);
            Int32 brcrvenih = Convert.ToInt32(BrojCrvenihTB.Text);
            string ime = ImeIgracaTB.Text;
            string prezime = PrezimeIgracaTB.Text;
            DateTime dat = Convert.ToDateTime(RodjenjeIgracaDP.Text);
            Boolean susp=false;
            if(DaRB.IsChecked==true)
            {
                susp=true;
            }
            else
            {
                susp=false;
            }

            Baza.Dal d= Baza.Dal.Instanca;
            d.kreirajKonekciju();

            Baza.Dal.IgracDa igrac = d.getDAO.getIgracDa();
            Igrac igr = new Igrac(ime,prezime,dat,user,susp,brzutih,brcrvenih,brojg,broja,drzavaTB.Text,jmbgTB.Text);
            igrac.create(igr);
            d.terminirajKonekciju();

            Thread nit;
            nit = new Thread(() =>
            {
                KorisnikPanel.i.Add(igr);
            });

            BrojAsistencijaTB.Clear();
            BrojCrvenihTB.Clear();
            BrojGolovaTB.Clear();
            BrojZutihTB.Clear();
            drzavaTB.Clear();
        }



     
    }
}
