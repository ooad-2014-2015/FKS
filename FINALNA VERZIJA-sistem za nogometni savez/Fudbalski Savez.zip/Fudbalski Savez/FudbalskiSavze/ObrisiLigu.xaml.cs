﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for ObrisiLigu.xaml
    /// </summary>
    public partial class ObrisiLigu : Window
    {
        MySqlConnection cn;
        MySqlDataAdapter da;
        DataSet ds;
        Baza.Dal d;
        List<Liga> lige = new List<Liga>();
        Baza.Dal.LigaDa liga;
        public ObrisiLigu()
        {   
            InitializeComponent();

            d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
            cn = d.dajKonekciju();


        }

        private void DataGridLiga_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            da = new MySqlDataAdapter("Select * from fks.liga", cn);
            ds = new DataSet();
            da.Fill(ds);
            DataGridLiga.ItemsSource = ds.Tables[0].DefaultView;
             liga = d.getDAO.getLigaDa();
            lige = liga.getAll();
            lige.RemoveAll(x => x.naziv== "admin");
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = lige;
        }

        private void Window_Closing_1(object sender, System.ComponentModel.CancelEventArgs e)
        {
            d.terminirajKonekciju();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int l = LigaCB.SelectedIndex;
            if (l > 0)
            {
                Liga LigaBrisi = lige[l];
                liga.delete(LigaBrisi);
                LigaCB.ItemsSource = null;
                LigaCB.ItemsSource = lige;
                da = new MySqlDataAdapter("Select * from fks.liga", cn);
                ds = new DataSet();
                da.Fill(ds);
                DataGridLiga.ItemsSource = ds.Tables[0].DefaultView;
                liga = d.getDAO.getLigaDa();
                if (liga.getAll() == null)
                    lige = new List<Liga>();
                else lige = liga.getAll();
            }

        }
    }
}
