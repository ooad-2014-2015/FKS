﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
            Baza.Dal.KorisnikDa korisnik = d.getDAO.getKorisnikDa();
            if (korisnik.getAll().Count == 0)
            {
                AdminPanel r = new AdminPanel();
                r.Show();
                MessageBox.Show("Prvi put pristupate aplikaciji kreirajte admina");
            }
            else
            {
                LogIn l = new LogIn();
                l.Show();
            }
           
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpWindow hl = new HelpWindow();
            hl.Show();
        }

       
    }
}
