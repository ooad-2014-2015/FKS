﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;
using System.Threading;
using System.ComponentModel;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for KorisnikPanel.xaml
    /// </summary>
    public partial class KorisnikPanel : Window
    {
        public Korisnik user;

        MySqlConnection cn;
        MySqlDataAdapter da;
        DataSet ds;
        Baza.Dal d;
        List<Igrac> igraci = new List<Igrac>();
        Baza.Dal.IgracDa igr;

        public static List<Igrac> igraciProvjera=new List<Igrac>();
        public static List<Igrac> igraciDupli=new List<Igrac>();

        private readonly BackgroundWorker worker = new BackgroundWorker();
       

        public KorisnikPanel(Korisnik k)
        {
            user = k;
            InitializeComponent();
            d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
            cn = d.dajKonekciju();
            worker.DoWork += worker_DoWork;
           

           
           
        }
        //PARALELIZAM
        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (igraciDupli.Count != 0)
            {
                foreach(var a in igraciDupli)
                {
                    if(a.klub.klub_id==user.klub.klub_id)
                    {
                        igraciNovo.Add(a);
                    }
                }
                if (igraciNovo.Count>0)
                    {
                    foreach(var a in igraciNovo)
                    {
                        igraciDupli.Remove(a);
                    }
                    MessageBox.Show("Bilo je promjena u vasem timu!!","Upozorenje",MessageBoxButton.OK,MessageBoxImage.Information);
                    }
                }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (igraciDG.SelectedIndex >= 0)
            {
                int l = igraciDG.SelectedIndex;
                if (igraci.Count == 0)
                {
                    MessageBox.Show("Nema igraca za obrisati!");
                }
                else
                {
                    Igrac IgracBrisi = igraci[l];
                    igr.delete(IgracBrisi);
                    igraci.Remove(IgracBrisi);

                    da = new MySqlDataAdapter("Select * from fks.igrac where klub_id="+user.klub.klub_id+";", cn);
                    ds = new DataSet();
                    da.Fill(ds);

                    igraciDG.ItemsSource = ds.Tables[0].DefaultView;
                    igr = d.getDAO.getIgracDa();
                    if (igr.getAll() == null)
                        igraci = new List<Igrac>();
                    else   igraci = igr.getAll();
                }
            }
        }
        Baza.Dal.KlubDa kl;
        public static List<Igrac> i;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            kl = d.getDAO.getKlubDa();
            Klub klub = new Klub();
            klub = kl.getByld(user.klub.klub_id);
            UnosIgraca u = new UnosIgraca(klub);
            u.Show();
        }
        public void dodaj()
        {
            if (i.Count != 0)
            {
                foreach (var a in i)
                {
                    if (a.klub.klub_id == user.klub.klub_id)
                        igraciDG.Items.Add(i);
                }
            }
        }
        public List<Igrac> igraciNovo=new List<Igrac>();
        private void KorisnikP_Loaded(object sender, RoutedEventArgs e)
        {
            da = new MySqlDataAdapter("Select * from fks.igrac where klub_id=" + user.klub.klub_id + ";", cn);
            ds = new DataSet();
            
            da.Fill(ds);
            if(igraciDupli.Count!=0)
            worker.RunWorkerAsync();

            igraciDG.ItemsSource = ds.Tables[0].DefaultView;
            igr = d.getDAO.getIgracDa();
            igraci = igr.getAll();
            igraciProvjera = igraci;
            
            foreach(var a in igraci)
            {
                if (igraciNovo.Contains(a) == true)
                { igraciNovo.Remove(a); }
            }
           
            
           
           }

        private void KorisnikP_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            d.terminirajKonekciju();
        }
    }
}
