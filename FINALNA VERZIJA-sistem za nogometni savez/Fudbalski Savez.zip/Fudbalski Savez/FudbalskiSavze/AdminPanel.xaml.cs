﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {

       
        List<Liga> lige = new List<Liga>();
        Baza.Dal.LigaDa liga;
        Baza.Dal t;
        int l ;
        int i;
        List<Klub> klubovi = new List<Klub>();
        Baza.Dal.KlubDa klub;


        public Liga dajLigu(int id)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();

            Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
            Liga l = null;
            l = liga.getByld(id);

            d.terminirajKonekciju();
            return l;
        }

        public AdminPanel()
        {
            try
            { 
                InitializeComponent();
            
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
           

        }

        private void PotvrdiLigaB_Click(object sender, RoutedEventArgs e)
        {

            Baza.Dal d = Baza.Dal.Instanca;
              d.kreirajKonekciju();
        

            Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
            Liga l = new Liga(Convert.ToInt32(BrojKlubovaTB.Text), Convert.ToDateTime(PocetakOdrzavanjaDP.Text), Convert.ToDateTime(KrajOdrzavanjaDP.Text), ImeLigeTB.Text.ToString());
            liga.create(l);

            d.terminirajKonekciju();

            ImeLigeTB.Clear();
            BrojKlubovaTB.Clear();
           
        }

        private void ObrisiLigaB_Click(object sender, RoutedEventArgs e)
        {
            ObrisiLigu o = new ObrisiLigu();
            o.Show();
        }

        private void PotvrdiKlubB_Click(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
           
       
          
            Liga LigaDodaj = lige[l];

            Baza.Dal.KlubDa klub = d.getDAO.getKlubDa();
            Klub k = null;
             k = new Klub(ImeTB.Text, GradTB.Text, 0, TrenerTB.Text, LigaDodaj, DateTime.Now);
          
            klub.create(k);

            d.terminirajKonekciju();

            ImeTB.Clear();
            GradTB.Clear();
            TrenerTB.Clear();
        }

        private void KlubPage1_Loaded(object sender, RoutedEventArgs e)
        {
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = lige;

        }

        private void LigaCB_MouseEnter(object sender, MouseEventArgs e)
        {
            t = Baza.Dal.Instanca;
            t.kreirajKonekciju();
            liga = t.getDAO.getLigaDa();
            lige = liga.getAll();
            lige.RemoveAll(x => x.liga_id == 4);
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = lige;
        }

        private void LigaCB_MouseLeave(object sender, MouseEventArgs e)
        {
            t.terminirajKonekciju();
        }

        private void LigaCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            l = LigaCB.SelectedIndex;
        }

        private void ObrisiKlub_Click(object sender, RoutedEventArgs e)
        {
            ObrisiKlub k = new ObrisiKlub();
            k.Show();
        }
        //Popravka
        private void UnesiKorB_Click(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();

            int i = KluboviCB.SelectedIndex;
            if (i > 0)
            {
                Klub KlubDodaj = klubovi[i];

                Baza.Dal.KorisnikDa kor = d.getDAO.getKorisnikDa();
                Korisnik k = null;

                k = new Korisnik(UsernameTB.Text, PassTB.Text, EmailTB.Text, KlubDodaj, DateTime.Now);
                kor.create(k);

                d.terminirajKonekciju();

                UsernameTB.Clear();
                EmailTB.Clear();
                PassTB.Clear();
            }
        }

        private void KluboviCB_MouseEnter(object sender, MouseEventArgs e)
        {
            t = Baza.Dal.Instanca;
            t.kreirajKonekciju();
            klub = t.getDAO.getKlubDa();
            klubovi = klub.getAll();
            klubovi.RemoveAll(x => x.klub_id == 4);
            KluboviCB.ItemsSource = null;
            KluboviCB.ItemsSource = klubovi;
        }

        private void KluboviCB_MouseLeave(object sender, MouseEventArgs e)
        {
            t.terminirajKonekciju();
        }

        private void KluboviCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            i = KluboviCB.SelectedIndex;
        }

        private void ObrisiKorB_Click(object sender, RoutedEventArgs e)
        {
            ObrisiKorisnika k = new ObrisiKorisnika();
            k.Show();
        }
        Baza.Dal d;
        MySqlConnection cn;
        List<Igrac> igraci;
        Baza.Dal.IgracDa igr;
        public static List<Igrac> igraciPromjena;
        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
            d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
            cn = d.dajKonekciju();
            MySqlDataAdapter da;
            DataSet ds;

            da = new MySqlDataAdapter("Select * from fks.igrac ;", cn);
            ds = new DataSet();
            da.Fill(ds);
            sviIgraciDG.ItemsSource = ds.Tables[0].DefaultView;
            igr = d.getDAO.getIgracDa();
            igraci = igr.getAll();
            igraciPromjena = igraci;
            //KorisnikPanel.igraciDupli = igraciPromjena;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sviIgraciDG.SelectedIndex >= 0)
            {
                int l = sviIgraciDG.SelectedIndex;
                if (igraci.Count == 0)
                {
                    MessageBox.Show("Nema igraca za povecati golove!");
                }
                else
                {
                    Igrac IgracPromjeni = igraci[l];
                    igr.updateGol(IgracPromjeni);
                    KorisnikPanel.igraciDupli.Add(IgracPromjeni);
                    IgracPromjeni.broj_golova = IgracPromjeni.broj_golova + 1;

                    d = Baza.Dal.Instanca;
                    d.kreirajKonekciju();
                    cn = d.dajKonekciju();
                    MySqlDataAdapter da;
                    DataSet ds;

                    da = new MySqlDataAdapter("Select * from fks.igrac ;", cn);
                    ds = new DataSet();
                    da.Fill(ds);

                    sviIgraciDG.ItemsSource = ds.Tables[0].DefaultView;
                    igr = d.getDAO.getIgracDa();
                    if (igr.getAll() == null)
                        igraci = new List<Igrac>();
                    else igraci = igr.getAll();
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (sviIgraciDG.SelectedIndex >= 0)
            {
                int l = sviIgraciDG.SelectedIndex;
                if (igraci.Count == 0)
                {
                    MessageBox.Show("Nema igraca za povecati golove!");
                }
                else
                {
                    Igrac IgracPromjeni = igraci[l];
                    igr.updateAsist(IgracPromjeni);
                    IgracPromjeni.broj_asistenciaj = IgracPromjeni.broj_asistenciaj + 1;
                    KorisnikPanel.igraciDupli.Add(IgracPromjeni);
                    d = Baza.Dal.Instanca;
                    d.kreirajKonekciju();
                    cn = d.dajKonekciju();
                    MySqlDataAdapter da;
                    DataSet ds;

                    da = new MySqlDataAdapter("Select * from fks.igrac ;", cn);
                    ds = new DataSet();
                    da.Fill(ds);

                    sviIgraciDG.ItemsSource = ds.Tables[0].DefaultView;
                    igr = d.getDAO.getIgracDa();
                    if (igr.getAll() == null)
                        igraci = new List<Igrac>();
                    else igraci = igr.getAll();
                }
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (sviIgraciDG.SelectedIndex >= 0)
            {
                int l = sviIgraciDG.SelectedIndex;
                if (igraci.Count == 0)
                {
                    MessageBox.Show("Nema igraca za povecati golove!");
                }
                else
                {
                    Igrac IgracPromjeni = igraci[l];
                    igr.updateZuti(IgracPromjeni);
                    IgracPromjeni.broj_zutih = IgracPromjeni.broj_zutih + 1;
                    KorisnikPanel.igraciDupli.Add(IgracPromjeni);
                    d = Baza.Dal.Instanca;
                    d.kreirajKonekciju();
                    cn = d.dajKonekciju();
                    MySqlDataAdapter da;
                    DataSet ds;

                    da = new MySqlDataAdapter("Select * from fks.igrac ;", cn);
                    ds = new DataSet();
                    da.Fill(ds);

                    sviIgraciDG.ItemsSource = ds.Tables[0].DefaultView;
                    igr = d.getDAO.getIgracDa();
                    if (igr.getAll() == null)
                        igraci = new List<Igrac>();
                    else igraci = igr.getAll();
                }
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (sviIgraciDG.SelectedIndex >= 0)
            {
                int l = sviIgraciDG.SelectedIndex;
                if (igraci.Count == 0)
                {
                    MessageBox.Show("Nema igraca za povecati golove!");
                }
                else
                {
                    Igrac IgracPromjeni = igraci[l];
                    igr.updateCrveni(IgracPromjeni);
                    IgracPromjeni.broj_crvenih = IgracPromjeni.broj_crvenih + 1;
                    KorisnikPanel.igraciDupli.Add(IgracPromjeni);
                    d = Baza.Dal.Instanca;
                    d.kreirajKonekciju();
                    cn = d.dajKonekciju();
                    MySqlDataAdapter da;
                    DataSet ds;

                    da = new MySqlDataAdapter("Select * from fks.igrac ;", cn);
                    ds = new DataSet();
                    da.Fill(ds);

                    sviIgraciDG.ItemsSource = ds.Tables[0].DefaultView;
                    igr = d.getDAO.getIgracDa();
                    if (igr.getAll() == null)
                        igraci = new List<Igrac>();
                    else igraci = igr.getAll();
                }
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
          
        }

       
    }
}
