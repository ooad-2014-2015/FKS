﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for ObrisiKorisnika.xaml
    /// </summary>
    public partial class ObrisiKorisnika : Window
    {
        MySqlConnection cn;
        MySqlDataAdapter da;
        DataSet ds;
        Baza.Dal d;
        List<Korisnik> korisnici = new List<Korisnik>();
        Baza.Dal.KorisnikDa korisnik;
        public ObrisiKorisnika()
        {
            InitializeComponent();
                d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
            cn = d.dajKonekciju();
        }
        
       

        private void DataGridLiga_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            da = new MySqlDataAdapter("Select * from fks.korisnik", cn);
            ds = new DataSet();
            da.Fill(ds);
            DataGridKorisnik.ItemsSource = ds.Tables[0].DefaultView;
            korisnik = d.getDAO.getKorisnikDa();
            korisnici = korisnik.getAll();
            korisnici.RemoveAll(x => x.korisnik_id == 4);
            KorisnikCB.ItemsSource = null;
            KorisnikCB.ItemsSource = korisnici;
        }

        private void Window_Closing_1(object sender, System.ComponentModel.CancelEventArgs e)
        {
            d.terminirajKonekciju();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int l = KorisnikCB.SelectedIndex;
            if (l >0)
            {
                Korisnik KorisnikBrisi = korisnici[l];
                korisnik.delete(KorisnikBrisi);
                korisnici.Remove(KorisnikBrisi);
                KorisnikCB.ItemsSource = null;
                KorisnikCB.ItemsSource = korisnici;
                da = new MySqlDataAdapter("Select * from fks.korisnik", cn);
                ds = new DataSet();
                da.Fill(ds);
                DataGridKorisnik.ItemsSource = ds.Tables[0].DefaultView;
                korisnik = d.getDAO.getKorisnikDa();
                if (korisnik.getAll() == null)
                    korisnici = new List<Korisnik>();
                else korisnici = korisnik.getAll();
            }

        }
    }
}
