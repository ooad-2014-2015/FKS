﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
namespace Baza
{
    public partial class Dal 
    {
        public class KorisnikDa : Interface< Korisnik >
        {
            protected MySqlCommand command;
            public struct KorisnikP
            {
                public int korisnik_id;
                public string username;
                public string password;
                public string email;
                public DateTime datum_kreiranja;
                public int klub;
        

        public KorisnikP (string username1, string password1, string emial1,int  k ,DateTime? datum=null,int id=0)
        {
            username=username1;
            password =password1;
            email=emial1;
            if (datum == null) datum_kreiranja = DateTime.Now;
           
            else datum_kreiranja = Convert.ToDateTime(datum);
            klub = k;
            korisnik_id = id;
           

           
        } 
            }

            public Klub dajKlub(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju();

                Baza.Dal.KlubDa klub = d.getDAO.getKlubDa();
                Klub l = null;
                l = klub.getByld(id);

                d.terminirajKonekciju();
                return l;
            }
            public long create(Korisnik entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Insert into fks.korisnik(username,password,email,klub_id,create_time) values ('" + entity.username + "','" + entity.password + "','" + entity.email + "'," + entity.klub.klub_id + ",date('" + entity.datum_kreiranja.ToString("yyyy.MM.dd") + "')) ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }


            public Korisnik read(Korisnik entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Select * from fks.korisnik where username = '" + entity.username + "' and password = '" + entity.password + "'  ; ";
                    command = new MySqlCommand(query,con);
                    /*
                    Baza.Dal d = Baza.Dal.Instanca;
                    d.kreirajKonekciju("localhost", "fks", "root", "root");

                    
                  
                    
                    command = new MySqlCommand(query,d.dajKonekciju());
                    MySqlDataReader r = command.ExecuteReader();
                    Korisnik z = null;
                    while (r.Read())
                    {
                        z = new Korisnik(r.GetString("username"), r.GetString("password"), r.GetString("email"),dajKlub(r.GetInt32("klub_id")),r.GetDateTime("create_time"),r.GetInt32("korisnik_id"));
                       

                    }
                    r.Close();
                    return z;
                    d.terminirajKonekciju();
                
                    */
                    List<Korisnik> z = new List<Korisnik>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KorisnikP> pom = new List<KorisnikP>();
                    while (r.Read())
                    {

                        pom.Add(new KorisnikP(r.GetString("username"), r.GetString("password"), r.GetString("email"), r.GetInt32("klub_id"), r.GetDateTime("create_time"), r.GetInt32("korisnik_id")));
                    }
                    r.Close();
                    foreach (KorisnikP p in pom)
                    {
                        z.Add(new Korisnik(p.username, p.password, p.email, dajKlub(p.klub), p.datum_kreiranja, p.korisnik_id));
                    }
                    return z[0];
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Korisnik update(Korisnik entity)
            {
                try
                {
                    refreshConnection();

                    string query = "update fks.korisnik set username ='" + entity.username + "',password= '" + entity.password + "', email= '" + entity.email + "',create_time =date('" + entity.datum_kreiranja.ToString("yyyy.MM.dd") + "') where korisnik_id = '" + entity.korisnik_id + "';";

                  
                    command = new MySqlCommand(query, con);
                    
                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Korisnik entity)
            {
                try
                {
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju();
                    refreshConnection();
                    string query = "delete from fks.korisnik where username= '" + entity.username + "';";

                    Console.WriteLine(query);
                    command = new MySqlCommand(query,d.dajKonekciju());

                    command.ExecuteNonQuery();
                    d.terminirajKonekciju();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Korisnik getByld(int  id)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.korisnik where korisnik_id = " + id + " ;", con);
                    List<Korisnik> z = new List<Korisnik>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KorisnikP> pom = new List<KorisnikP>();
                    while (r.Read())
                    {

                        pom.Add(new KorisnikP(r.GetString("username"), r.GetString("password"), r.GetString("email"), r.GetInt32("klub_id"), r.GetDateTime("create_time"), r.GetInt32("korisnik_id")));
                    }
                    r.Close();
                    foreach (KorisnikP p in pom)
                    {
                        z.Add(new Korisnik(p.username, p.password, p.email, dajKlub(p.klub), p.datum_kreiranja, p.korisnik_id));
                    }
                    return z[0];
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Korisnik> getAll()
            {

                try
                {
                    refreshConnection();
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju();
                    command = new MySqlCommand("select * from fks.korisnik", con);
                    List<Korisnik> z = new List<Korisnik>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KorisnikP> pom = new List<KorisnikP>();
                    while (r.Read())
                    {

                        pom.Add(new KorisnikP(r.GetString("username"), r.GetString("password"), r.GetString("email"), r.GetInt32("klub_id"), r.GetDateTime("create_time"), r.GetInt32("korisnik_id")));
                    }
                    r.Close();
                    foreach (KorisnikP p in pom)

                    {
                        z.Add(new Korisnik(p.username,p.password,p.email,dajKlub(p.klub),p.datum_kreiranja,p.korisnik_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Korisnik> getByExample(string name, string value)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("Select * from fks.korisnik where '" + name + "'='" + value + "'", con);
                    List<Korisnik> z = new List<Korisnik>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KorisnikP> pom = new List<KorisnikP>();
                    while (r.Read())
                    {

                        pom.Add(new KorisnikP(r.GetString("username"), r.GetString("password"), r.GetString("email"), r.GetInt32("klub_id"), r.GetDateTime("create_time"), r.GetInt32("korisnik_id")));
                    }
                    r.Close();
                    foreach (KorisnikP p in pom)
                    {
                        z.Add(new Korisnik(p.username, p.password, p.email, dajKlub(p.klub), p.datum_kreiranja, p.korisnik_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

        }



    }
}
