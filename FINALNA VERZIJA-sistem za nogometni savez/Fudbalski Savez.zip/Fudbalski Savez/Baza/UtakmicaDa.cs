﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Baza
{
    public partial class Dal
    {
        public class UtakmicaDa : Interface<Utakmica>
        {
            protected MySqlCommand command;
            public struct UtakmicaP
            {
               public int utakmica_id ;
        public int domaci;
        public int  gosti ;
        public int rezultat_gosti ;
        public int rezultat_domaci ;
        public string mjesto ;
        public string stadion;
        public DateTime datum_odrzavanja ;
        public int kolo;
        public string glavni_sudija ;

        public UtakmicaP(int dom,int  gos, int rez_dom, int rez_gos, string mjesto1, string stadion1, DateTime odrzavanje, int k, string sudija,int id=0)
        {
            domaci = dom;
            gosti = gos;
            rezultat_domaci=rez_dom;
            rezultat_gosti=rez_gos;
            mjesto=mjesto1;
            stadion=stadion1;
            datum_odrzavanja=odrzavanje;
            kolo = k;
            glavni_sudija= sudija;
            utakmica_id=id;

        }
            }
            public Kolo dajKolo(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju();

                Baza.Dal.KoloDa kolo = d.getDAO.getKoloDa();
                Kolo k = null;
                k = kolo.getByld(id);

                d.terminirajKonekciju();
                return k;
            }
            public Klub dajKlub(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju();

                Baza.Dal.KlubDa klub = d.getDAO.getKlubDa();
                Klub l = null;
                l = klub.getByld(id);

                d.terminirajKonekciju();
                return l;
            }
            public long create(Utakmica entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Insert into fks.utakmica(domaci_id,gosti_id,rezultat_domaci,rezultat_gosti,mjesto,stadion,datum_odrzavanja,kolo_id,glavni_sudija,utakmica_id) values (" + entity.domaci.klub_id + "," + entity.gosti.klub_id + "," + entity.rezultat_domaci + "," + entity.rezultat_gosti + ",'" + entity.mjesto + "','" + entity.stadion + "',date('" + entity.datum_odrzavanja.ToString("yyyy.MM.dd") + "'),'" + entity.glavni_sudija+ "') ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }


            public Utakmica read(Utakmica entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Select * from fks.utakmica where utakmica_id=" + entity.utakmica_id + ";";


                    command = new MySqlCommand(query, con);
                    List<Utakmica> z = new List<Utakmica>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<UtakmicaP> pom = new List<UtakmicaP>();
                    while (r.Read())
                    {
                        pom.Add(new UtakmicaP(r.GetInt32(0), r.GetInt32(1), r.GetInt32(2), r.GetInt32(3), r.GetString(4), r.GetString(5), r.GetDateTime(6), r.GetInt32(7), r.GetString(8), r.GetInt32(9)));
                    }
                    r.Close();
                    foreach (UtakmicaP p in pom)
                    {
                        z.Add(new Utakmica(dajKlub(p.domaci), dajKlub(p.gosti), p.rezultat_domaci, p.rezultat_gosti, p.mjesto, p.stadion, p.datum_odrzavanja, dajKolo(p.kolo), p.glavni_sudija, p.utakmica_id));
                    }
                    return z[0];

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Utakmica update(Utakmica entity)
            {
                try
                {
                    refreshConnection();
                    string query = "update fks.utakmica set domaci_id = " + entity.domaci.klub_id + ",gosti_id =" + entity.gosti.klub_id + ",rezultat_domaci =" + entity.rezultat_domaci + ",rezultat_gosti = " + entity.rezultat_gosti + ",mjesto = '" + entity.mjesto + "',stadion ='" + entity.stadion + "',datum_odrzavanja = date('" + entity.datum_odrzavanja.ToString("yyyy.MM.dd") + "'),kolo_id =" + entity.kolo + " where utakmica_id = '" + entity.utakmica_id + "';";


                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Utakmica entity)
            {
                try
                {
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju();
                    refreshConnection();
                    string query = "delete from fks.utakmica where utakmica_id= " + entity.utakmica_id + ";";

                    Console.WriteLine(query);
                    command = new MySqlCommand(query, d.dajKonekciju());

                    command.ExecuteNonQuery();
                    d.terminirajKonekciju();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Utakmica getByld(int id)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.utakmica where utakmica_id = " + id + " ;", con);
                    List<Utakmica> z = new List<Utakmica>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<UtakmicaP> pom = new List<UtakmicaP>();
                    while (r.Read())
                    {
                        pom.Add(new UtakmicaP(r.GetInt32(0), r.GetInt32(1), r.GetInt32(2), r.GetInt32(3), r.GetString(4), r.GetString(5), r.GetDateTime(6), r.GetInt32(7), r.GetString(8), r.GetInt32(9)));
                    }
                    r.Close();
                    foreach (UtakmicaP p in pom)
                    {
                        z.Add(new Utakmica(dajKlub(p.domaci), dajKlub(p.gosti), p.rezultat_domaci, p.rezultat_gosti, p.mjesto, p.stadion, p.datum_odrzavanja, dajKolo(p.kolo), p.glavni_sudija, p.utakmica_id));
                    }
                    return z[0];
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Utakmica> getAll()
            {

                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.utakmica ;", con);
                    List<Utakmica> z = new List<Utakmica>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<UtakmicaP> pom = new List<UtakmicaP>();
                    while (r.Read())
                    {
                        pom.Add(new UtakmicaP(r.GetInt32(0), r.GetInt32(1), r.GetInt32(2), r.GetInt32(3), r.GetString(4), r.GetString(5), r.GetDateTime(6), r.GetInt32(7), r.GetString(8), r.GetInt32(9)));
                    }
                    r.Close();
                    foreach (UtakmicaP p in pom)
                    {
                        z.Add(new Utakmica(dajKlub(p.domaci), dajKlub(p.gosti), p.rezultat_domaci, p.rezultat_gosti, p.mjesto, p.stadion, p.datum_odrzavanja, dajKolo(p.kolo), p.glavni_sudija, p.utakmica_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Utakmica> getByExample(string name, string value)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.utakmica where '" + name + "'='" + value + "' ;", con);
                    List<Utakmica> z = new List<Utakmica>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<UtakmicaP> pom = new List<UtakmicaP>();
                    while (r.Read())
                    {
                        pom.Add(new UtakmicaP(r.GetInt32(0),r.GetInt32(1),r.GetInt32(2),r.GetInt32(3),r.GetString(4),r.GetString(5),r.GetDateTime(6),r.GetInt32(7),r.GetString(8),r.GetInt32(9)));
                    }
                    r.Close();
                    foreach (UtakmicaP p in pom)
                    {
                        z.Add(new Utakmica(dajKlub(p.domaci),dajKlub(p.gosti),p.rezultat_domaci,p.rezultat_gosti,p.mjesto,p.stadion,p.datum_odrzavanja,dajKolo(p.kolo),p.glavni_sudija,p.utakmica_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

        }



    }
}
