﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public class Klub
    {


        public int klub_id { get; set; }
        public string naziv { get; set; }
        public string grad { get; set; }
        public string trener { get; set; }
        public DateTime datum_registrcije { get; set; }
        public int  stream { get; set; }
        public Liga  liga { get; set; }


        public Klub(string naziv1, string grad1, int stream1, string trener1, Liga l, DateTime? d = null, int id = 0)
        {
          naziv=naziv1;
            grad=grad1;
            trener=trener1;
            if (d == null) datum_registrcije = DateTime.Now;
            else datum_registrcije = Convert.ToDateTime(d);
            stream=stream1;
            liga=l;
            klub_id = id;
        }

        public Klub(Klub k)
        {
            naziv = k.naziv;
            grad = k.grad;
            trener = k.trener;
            if (k.datum_registrcije == null) datum_registrcije = DateTime.Now;
            else datum_registrcije = Convert.ToDateTime(k.datum_registrcije);
            stream = k.stream;
            liga = k.liga;
            klub_id = k.klub_id;
        }

        public Klub()
        {

        }


        public override string ToString()
{
 	return ("Klub: " + naziv + Environment.NewLine + "grad: " +  grad + Environment.NewLine + " datum registracije: " + datum_registrcije.ToString() + Environment.NewLine + " liga: " + liga.naziv + Environment.NewLine + " trener: " + trener + Environment.NewLine );

}
    }
}
