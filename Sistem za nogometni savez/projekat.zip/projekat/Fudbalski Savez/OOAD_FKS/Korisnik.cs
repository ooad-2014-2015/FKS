﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public class Korisnik
    {
        public int korisnik_id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public DateTime datum_kreiranja { get; set; }
        public Klub klub { get; set; }
        

        public Korisnik (string username1, string password1, string emial1=" " ,Klub k = null ,DateTime? datum=null,int id=0)
        {
            username=username1;
            password =password1;
            email=emial1;
            if (datum == null) datum_kreiranja = DateTime.Now;
           
            else datum_kreiranja = Convert.ToDateTime(datum);
            if (k == null) klub = new Klub();
            else klub = k;
            korisnik_id = id;
           

           
        }
        public Korisnik(Korisnik k)
        {
            username = k.username;
            password = k.password;
            email = k.email;
            if (k.datum_kreiranja == null) datum_kreiranja = DateTime.Now;
            else datum_kreiranja = Convert.ToDateTime(k.datum_kreiranja);
            korisnik_id = k.korisnik_id;
            if (k.klub == null) klub = new Klub();
            else klub = k.klub;


        }
        public Korisnik()
        {

        }


        public override string ToString()
     {
 	return ("Korisnik: " + username + " email: " + email + Environment.NewLine + "datum kreiranja: " +  datum_kreiranja );

     }     


    }
}
