﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_FKS
{
    public class Igrac
    {   public int igrac_id {get; set;}
        public string ime    { get; set; }
        public string prezime { get; set; }
        public DateTime datum_rodjenja { get; set; }
        public DateTime datum_registracije { get; set; }
        public Klub klub {get; set;}
        public bool suspenzija {get; set;}
        public int broj_zutih {get; set;}
        public int broj_crvenih {get; set;}
        public int broj_golova {get; set;}
        public int broj_asistenciaj {get; set;}
        public string drzava {get; set;}
        public string jmbg {get; set;}



        public Igrac(string ime1, string prezime1, DateTime rod, Klub k, bool suspenzija1, int zuti, int crveni, int golovi, int ass, string drzava1, string jmbg1, DateTime? reg=null, int id = 0)
        {
            igrac_id=id;
            ime=ime1;
            prezime=prezime1;
            datum_rodjenja=rod;
            if (reg == null) datum_registracije = DateTime.Now;
            else datum_registracije = Convert.ToDateTime(reg);
          
            klub=k;
            suspenzija=suspenzija1;
            broj_zutih=zuti;
            broj_golova=golovi;
            broj_crvenih=crveni;
            broj_asistenciaj=ass;
            drzava=drzava1;
            jmbg=jmbg1;
           
        }
        public Igrac(Igrac i)
        {
            igrac_id = i.igrac_id;
            ime = i.ime;
            prezime = i.prezime;
            datum_rodjenja =i.datum_rodjenja;
            if (i.datum_registracije == null) datum_registracije = DateTime.Now;
            else datum_registracije = Convert.ToDateTime(i.datum_registracije);

            klub = i.klub;
            suspenzija = i.suspenzija;
            broj_zutih = i.broj_zutih;
            broj_golova = i.broj_golova;
            broj_crvenih = i.broj_crvenih;
            broj_asistenciaj = i.broj_asistenciaj;
            drzava = i.drzava;
            jmbg = i.jmbg;
        }

        public Igrac()
        {

        }


        public override string ToString()
        {
            return ("Ime i prezime : " + ime +" "+prezime+ Environment.NewLine + "datum rođenja : " + datum_rodjenja+ Environment.NewLine+" drzava : "+drzava 
                + Environment.NewLine +" jmbg: "+jmbg +Environment.NewLine);

        }
  
    }
}
