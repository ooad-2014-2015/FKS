﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;
using System.Security;


namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for LogIn.xaml
    /// </summary>
    public partial class LogIn : Window
    {
         public LogIn()
        {

            try { InitializeComponent(); }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju("localhost", "fks", "root", "Vela");
            Baza.Dal.KorisnikDa kor = d.getDAO.getKorisnikDa();

            String pass = passText.Password;
          
            MessageBox.Show(pass);
            Korisnik korr = new Korisnik(usernameText.Text.ToString(), pass);
            Korisnik k = new Korisnik( kor.read(korr));
            AdminPanel a =new AdminPanel();

            KorisnikPanel ko = new KorisnikPanel(k);
            if (k.password == korr.password)
                a.Show();
                else
            { 
                
                ko.Show();
            }
            
               
            
        }

        private void ButtonGost_Click(object sender, RoutedEventArgs e)
        {
            Pregled p = new Pregled();
            p.Show();
        }
    }
}
