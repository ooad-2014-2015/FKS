﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for ObrisiKlub.xaml
    /// </summary>
    public partial class ObrisiKlub : Window
    {
        MySqlConnection cn;
        MySqlDataAdapter da;
        DataSet ds;
        Baza.Dal d;
        List<Klub> klubovi = new List<Klub>();
        Baza.Dal.KlubDa klub;
        public ObrisiKlub()
        {
            InitializeComponent();

            d = Baza.Dal.Instanca;
            d.kreirajKonekciju("localhost", "fks", "root", "Vela");
            cn = d.dajKonekciju();

        }
        
        

        private void DataGridLiga_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            da = new MySqlDataAdapter("Select * from fks.klub", cn);
            ds = new DataSet();
            da.Fill(ds);
            DataGridLiga.ItemsSource = ds.Tables[0].DefaultView;
             klub = d.getDAO.getKlubDa();
            klubovi = klub.getAll();
            klubovi.RemoveAll(x => x.naziv == "admin");
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = klubovi;
        }

        private void Window_Closing_1(object sender, System.ComponentModel.CancelEventArgs e)
        {
            d.terminirajKonekciju();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int l = LigaCB.SelectedIndex;
            Klub KlubBrisi = klubovi[l];
            klub.delete(KlubBrisi);
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = klubovi;

        }
    }
}
