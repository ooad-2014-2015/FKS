﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Baza;
using OOAD_FKS;

namespace FudbalskiSavze
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {

       
        List<Liga> lige = new List<Liga>();
        Baza.Dal.LigaDa liga;
        Baza.Dal t;
        int l ;
        int i;
        List<Klub> klubovi = new List<Klub>();
        Baza.Dal.KlubDa klub;


        public Liga dajLigu(int id)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju("localhost", "fks", "root", "Vela");

            Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
            Liga l = null;
            l = liga.getByld(id);

            d.terminirajKonekciju();
            return l;
        }

        public AdminPanel()
        {
            try { InitializeComponent(); }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
           

        }

        private void PotvrdiLigaB_Click(object sender, RoutedEventArgs e)
        {

            Baza.Dal d = Baza.Dal.Instanca;
              d.kreirajKonekciju();
        

            Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
            Liga l = new Liga(Convert.ToInt32(BrojKlubovaTB.Text), Convert.ToDateTime(PocetakOdrzavanjaDP.Text), Convert.ToDateTime(KrajOdrzavanjaDP.Text), ImeLigeTB.Text.ToString());
            liga.create(l);

            d.terminirajKonekciju();
           
        }

        private void ObrisiLigaB_Click(object sender, RoutedEventArgs e)
        {
            ObrisiLigu o = new ObrisiLigu();
            o.Show();
        }

        private void PotvrdiKlubB_Click(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();
           
       
          
            Liga LigaDodaj = lige[l];

            Baza.Dal.KlubDa klub = d.getDAO.getKlubDa();
            Klub k = null;
             k = new Klub(ImeTB.Text, GradTB.Text, 0, TrenerTB.Text, LigaDodaj, DateTime.Now);
          
            klub.create(k);

            d.terminirajKonekciju();
        }

        private void KlubPage1_Loaded(object sender, RoutedEventArgs e)
        {
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = lige;

        }

        private void LigaCB_MouseEnter(object sender, MouseEventArgs e)
        {
            t = Baza.Dal.Instanca;
            t.kreirajKonekciju("localhost", "fks", "root", "Vela");
            liga = t.getDAO.getLigaDa();
            lige = liga.getAll();
            lige.RemoveAll(x => x.liga_id == 4);
            LigaCB.ItemsSource = null;
            LigaCB.ItemsSource = lige;
        }

        private void LigaCB_MouseLeave(object sender, MouseEventArgs e)
        {
            t.terminirajKonekciju();
        }

        private void LigaCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            l = LigaCB.SelectedIndex;
        }

        private void ObrisiKlub_Click(object sender, RoutedEventArgs e)
        {
            ObrisiKlub k = new ObrisiKlub();
            k.Show();
        }

        private void UnesiKorB_Click(object sender, RoutedEventArgs e)
        {
            Baza.Dal d = Baza.Dal.Instanca;
            d.kreirajKonekciju();



            Klub KlubDodaj = klubovi[l];

            Baza.Dal.KorisnikDa kor = d.getDAO.getKorisnikDa();
            Korisnik k = null;
            
             k = new Korisnik(UsernameTB.Text,PassTB.Text,EmailTB.Text,KlubDodaj,DateTime.Now);
            kor.create(k);

            d.terminirajKonekciju();
        }

        private void KluboviCB_MouseEnter(object sender, MouseEventArgs e)
        {
            t = Baza.Dal.Instanca;
            t.kreirajKonekciju("localhost", "fks", "root", "Vela");
            klub = t.getDAO.getKlubDa();
            klubovi = klub.getAll();
            klubovi.RemoveAll(x => x.klub_id == 4);
            KluboviCB.ItemsSource = null;
            KluboviCB.ItemsSource = klubovi;
        }

        private void KluboviCB_MouseLeave(object sender, MouseEventArgs e)
        {
            t.terminirajKonekciju();
        }

        private void KluboviCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            i = KluboviCB.SelectedIndex;
        }

        private void ObrisiKorB_Click(object sender, RoutedEventArgs e)
        {
            ObrisiKorisnika k = new ObrisiKorisnika();
            k.Show();
        }

       
    }
}
