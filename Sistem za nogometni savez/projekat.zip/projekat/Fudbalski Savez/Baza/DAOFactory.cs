﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baza
{
    partial class Dal
    {
        public class DAOFactory             // Inner klasa 
        {
            // Method factory dizajn pattern
            // public enum FactoryTip { MySQL }
            // public static DAOFactory GetDAOFactory(FactoryTip tip){
            //    switch (tip)
            //    {
            //        case FactoryTip.MySQL:
            //            return new MySQLDAOFactory();
            //    }
            //}

            private static DAOFactory instanca = null;

            public static DAOFactory Instanca
            {
                get { return (instanca == null) ? instanca = new DAOFactory() : instanca; }
            }

            private DAOFactory() { }

            //public Baza.Dal.LigaDa getLigaDa()
            //{
            //    return new Baza.Dal.LigaDa();
            //}

            public Baza.Dal.KorisnikDa getKorisnikDa()
            {
                return new Baza.Dal.KorisnikDa();
            }

            public Baza.Dal.LigaDa getLigaDa()
            {
              return new Baza.Dal.LigaDa();
            }

            public Baza.Dal.UtakmicaDa getUtakmicaDa()
            {
                return new Baza.Dal.UtakmicaDa();
            }

            public Baza.Dal.IgracDa getIgracDa()
            {
                return new Baza.Dal.IgracDa();
            }
            public Baza.Dal.KoloDa getKoloDa()
            {
                return new Baza.Dal.KoloDa();
            }
            public Baza.Dal.KlubDa getKlubDa()
            {
                return new Baza.Dal.KlubDa();
            }
           


        }
    }
}
