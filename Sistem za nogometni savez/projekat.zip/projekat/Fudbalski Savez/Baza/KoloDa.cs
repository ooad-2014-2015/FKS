﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Baza
{
    public partial class Dal
    {
        public class KoloDa : Interface<Kolo>
        {
            protected MySqlCommand command;
            public struct KoloP
            {

                public int kolo_id;
                public int redni_broj;
                public int broj_utakmica;
                public int liga;
       

        public KoloP(int redni ,int broj , int  l, int id=0)
        {
            redni_broj=redni;
            broj_utakmica=broj;
            liga=l;
            kolo_id = id;
        }
            }
            public Liga dajLigu(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju("localhost", "fks", "root", "Vela");

                Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
                Liga l = null;
                l = liga.getByld(id);

                d.terminirajKonekciju();
                return l;
            }


            public long create(Kolo entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Insert into fks.kolo (redni_broj_kola,broj_utakmica,liga_id) values (" + entity.redni_broj + "," + entity.broj_utakmica + "," + entity.liga.liga_id+") ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }


            public Kolo  read(Kolo entity)
            {
                try
                {
                    string query = "Select * from fks.kolo where kolo_id =" + entity.kolo_id +  ";";

                    command = new MySqlCommand(query, con);
                    List<Kolo> z = new List<Kolo>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KoloP> pom = new List<KoloP>();



                    while (r.Read())
                    {

                        pom.Add(new KoloP(r.GetInt32("redni_broj_kola"), r.GetInt32("broj_utakmica"), r.GetInt32("liga_id"), r.GetInt32("kolo_id")));

                    }

                    r.Close();
                    foreach (KoloP p in pom)
                    {
                        z.Add(new Kolo(p.redni_broj, p.broj_utakmica, dajLigu(p.liga), p.kolo_id));
                    }
                    return z[0];
                                      
                                      
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Kolo update(Kolo entity)
            {
                try
                {
                    refreshConnection();

                    string query = "update fks.liga set redni_broj_kola =" + entity.redni_broj + ",broj_utakmica= " + entity.broj_utakmica + ", liga_id= " + entity.liga + " where kolo_id = " + entity.kolo_id + ";";


                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Kolo entity)
            {
                try
                {
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju("localhost", "fks", "root", "Vela");
                    refreshConnection();
                 

             
                    string query = "delete from fks.kolo where kolo_id = " + entity.kolo_id + ";";

                    Console.WriteLine(query);
                    command = new MySqlCommand(query,d.dajKonekciju());

                    command.ExecuteNonQuery();
                    d.terminirajKonekciju();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Kolo getByld(int id1)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.kolo where liga_id = " + id1 + " ;", con);
                    List<Kolo> z = new List<Kolo>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KoloP> pom = new List<KoloP>();



                    while (r.Read())
                    {

                        pom.Add(new KoloP(r.GetInt32("redni_broj_kola"), r.GetInt32("broj_utakmica"), r.GetInt32("liga_id"), r.GetInt32("kolo_id")));

                    }

                    r.Close();
                    foreach (KoloP p in pom)
                    {
                        z.Add(new Kolo(p.redni_broj, p.broj_utakmica, dajLigu(p.liga), p.kolo_id));
                    }
                    return z[0];
                              
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Kolo> getAll()
            {

                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.kolo", con);
                    List<Kolo> z = new List<Kolo>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KoloP> pom = new List<KoloP>();
                   


                    while (r.Read())
                    {

                        pom.Add(new KoloP(r.GetInt32("redni_broj_kola"), r.GetInt32("broj_utakmica"),r.GetInt32("liga_id"), r.GetInt32("kolo_id")));

                    }

                    r.Close();
                    foreach (KoloP p in pom)
                    {
                        z.Add(new Kolo(p.redni_broj,p.broj_utakmica,dajLigu(p.liga),p.kolo_id));
                    }
                    return z;
                              
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Kolo> getByExample(string name, string value)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.kolo where '" + name + "'='" + value + "'", con);
                    List<Kolo> z = new List<Kolo>();
                    MySqlDataReader r = command.ExecuteReader();
                    List<KoloP> pom = new List<KoloP>();



                    while (r.Read())
                    {

                        pom.Add(new KoloP(r.GetInt32("redni_broj_kola"), r.GetInt32("broj_utakmica"), r.GetInt32("liga_id"), r.GetInt32("kolo_id")));

                    }

                    r.Close();
                    foreach (KoloP p in pom)
                    {
                        z.Add(new Kolo(p.redni_broj, p.broj_utakmica, dajLigu(p.liga), p.kolo_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

        }



    }
}
