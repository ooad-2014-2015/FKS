﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Baza
{
    public partial class Dal
    {
        public class KlubDa : Interface<Klub>
        {
            protected MySqlCommand command;
            public  struct KlubP
            {
                public int klub_id ;
                public string naziv ;
                public string grad;
                public string trener;
                public DateTime datum_registrcije;
                public int stream;
                public int liga; 

                 public KlubP (string naziv1, string grad1, int stream1, string trener1, int l, DateTime? d = null, int id = 0)
        {
          naziv=naziv1;
            grad=grad1;
            trener=trener1;
            if (d == null) datum_registrcije = DateTime.Now;
            else datum_registrcije = Convert.ToDateTime(d);
            stream=stream1;
            liga=l;
            klub_id = id;
        }
            }
            public Liga dajLigu(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju("localhost", "fks", "root", "Vela");

                Baza.Dal.LigaDa liga = d.getDAO.getLigaDa();
                Liga l = null;
                l = liga.getByld(id);

                d.terminirajKonekciju();
                return l;
            }
            public long create(Klub entity)
            {
                try
                {
                    string query = "Insert into fks.klub(naziv,grad,live_stream,trener,liga_id,datum_registracije) values ('" + entity.naziv + "','" + entity.grad + "'," + (int)entity.stream + ",'" + entity.trener + "'," + entity.liga.liga_id + ",date('" + entity.datum_registrcije.ToString("yyyy.MM.dd") + "')) ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }


            public Klub read(Klub entity)
            {
                try
                {
                    string query = "Select * from fks.klub where klub_id=" + entity.klub_id + ";";


                    command = new MySqlCommand(query, con);
                    List<Klub> z = new List<Klub>();
                    MySqlDataReader m = command.ExecuteReader();
                    List<KlubP> pom = new List<KlubP>();
                    while (m.Read())
                    {

                        pom.Add(new KlubP(m.GetString("naziv"), m.GetString("grad"), m.GetInt32("live_stream"), m.GetString("trener"), m.GetInt32("liga_id"), m.GetDateTime("datum_registracije"), m.GetInt32("klub_id")));
                    }
                    m.Close();
                    foreach (KlubP p in pom)
                    {
                        z.Add(new Klub(p.naziv, p.grad, p.stream, p.trener, dajLigu(p.liga), p.datum_registrcije, p.klub_id));
                    }
                    return z[0];

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Klub update(Klub entity)
            {
                try
                {
                    refreshConnection();
                    string query = "update fks.klub set naziv ='" + entity.naziv + "',grad = '" + entity.grad + "',live_stream =" + (int)entity.stream + ",trener ='" + entity.trener + "',klub_id =" + entity.klub_id + ",datum_registracije =date('" + entity.datum_registrcije.ToString("yyyy.MM.dd") + "')";

                    

                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Klub entity)
            {
                try
                {
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju("localhost", "fks", "root", "Vela");
                    refreshConnection();
                    string query = "delete from fks.klub where klub_id= " + entity.klub_id + ";";

                    Console.WriteLine(query);
                    command = new MySqlCommand(query,d.dajKonekciju());
                   
                    command.ExecuteNonQuery();
                    d.terminirajKonekciju();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Klub getByld(int  id)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.klub where klub_id = '" + id + "' ;", con);
                    List<Klub> z = new List<Klub>();
                    MySqlDataReader m = command.ExecuteReader();
                    List<KlubP> pom = new List<KlubP>();
                    while (m.Read())
                    {

                        pom.Add(new KlubP(m.GetString("naziv"), m.GetString("grad"), m.GetInt32("live_stream"), m.GetString("trener"), m.GetInt32("liga_id"), m.GetDateTime("datum_registracije"), m.GetInt32("klub_id")));
                    }
                    m.Close();
                    foreach (KlubP p in pom)
                    {
                        z.Add(new Klub(p.naziv, p.grad, p.stream, p.trener, dajLigu(p.liga), p.datum_registrcije, p.klub_id));
                    }
                    return z[0];
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Klub> getAll()
            {

                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.klub;", con);
                    List<Klub> z = new List<Klub>();
                    MySqlDataReader m = command.ExecuteReader();
                    List<KlubP> pom = new List<KlubP>();
                    while (m.Read())
                    {

                       pom.Add(new KlubP (m.GetString("naziv"), m.GetString("grad"), m.GetInt32("live_stream"), m.GetString("trener"), m.GetInt32("liga_id"), m.GetDateTime("datum_registracije"), m.GetInt32("klub_id")));
                    }
                    m.Close();
                    foreach (KlubP p in pom)
                    {
                        z.Add(new Klub(p.naziv,p.grad,p.stream,p.trener,dajLigu(p.liga),p.datum_registrcije,p.klub_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Klub> getByExample(string name, string value)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.klub where '" + name + "'='" + value + "'", con);
                    List<Klub> z = new List<Klub>();
                    MySqlDataReader m = command.ExecuteReader();
                    List<KlubP> pom = new List<KlubP>();
                    while (m.Read())
                    {

                        pom.Add(new KlubP(m.GetString("naziv"), m.GetString("grad"), m.GetInt32("live_stream"), m.GetString("trener"), m.GetInt32("liga_id"), m.GetDateTime("datum_registracije"), m.GetInt32("klub_id")));
                    }
                    m.Close();
                    foreach (KlubP p in pom)
                    {
                        z.Add(new Klub(p.naziv, p.grad, p.stream, p.trener, dajLigu(p.liga), p.datum_registrcije, p.klub_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }


        }



    }
}
