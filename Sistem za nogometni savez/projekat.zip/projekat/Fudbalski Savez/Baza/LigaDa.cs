﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
namespace Baza
{
    public partial class Dal
    {
        public class LigaDa : Interface<Liga>
        {
            protected MySqlCommand command;


            public long create(Liga entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Insert into fks.liga(broj_klubova,pocetak,kraj,naziv) values (" + entity.broj_klubova + ",date('" + entity.pocetak.ToString("yyyy.MM.dd") + "'),date('" + entity.kraj.ToString("yyyy.MM.dd") + "'),'" + entity.naziv+ "') ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public Liga  read(Liga  entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Select * from fks.liga where liga_id =" + entity.liga_id + ";";


                    command = new MySqlCommand(query, con);
                    MySqlDataReader r = command.ExecuteReader();
                    Liga z = null;
                    while (r.Read())
                    {
                        z = new Liga (r.GetInt32 ("broj_klubova"), r.GetDateTime("pocetak"), r.GetDateTime("kraj"),r.GetString("naziv"),r.GetInt32("liga_id"));
                        return z;

                    }
                    r.Close();
                    return z;

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Liga update(Liga entity)
            {
                try
                {
                    refreshConnection();

                    string query = "update fks.liga  set broj_klubova =" + entity.broj_klubova + ",pocetak =date('" + entity.pocetak.ToString("yyyy.MM.dd") + "'),kraj =date('" + entity.kraj.ToString("yyyy.MM.dd") + "'), naziv ='" + entity.naziv + "' where liga_id = " + entity.liga_id + " ;";


                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Liga entity)
            {
                try
                {
                    refreshConnection();
                    string query = "delete from fks.liga where liga_id= " + entity.liga_id + ";";

                    Console.WriteLine(query);
                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Liga getByld(int  id )
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.liga where liga_id = " + id + " ;", con);
                    MySqlDataReader r = command.ExecuteReader();
                    Liga s = null;
                    while (r.Read())
                    {
                        s = new Liga(r.GetInt32("broj_klubova"), r.GetDateTime("pocetak"), r.GetDateTime("kraj"), r.GetString("naziv"), r.GetInt32("liga_id"));
                        return s;

                    }
                    r.Close();
                    return s;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Liga> getAll()
            {

                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.liga ;", con);
                    List<Liga> z = new List<Liga>();
                    MySqlDataReader r = command.ExecuteReader();

                    while (r.Read())
                    {
                        z.Add(new Liga(r.GetInt32("broj_klubova"), r.GetDateTime("pocetak"), r.GetDateTime("kraj"), r.GetString("naziv"), r.GetInt32("liga_id")));
                    }
                    r.Close();
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Liga> getByExample(string name, string value)
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.liga where '" + name + "'='" + value + "' ;", con);
                    List<Liga> z = new List<Liga>();
                    MySqlDataReader r = command.ExecuteReader();
                    while (r.Read())
                    {
                        z.Add(new Liga(r.GetInt32("broj_klubova"), r.GetDateTime("pocetak"), r.GetDateTime("kraj"), r.GetString("naziv"), r.GetInt32("liga_id")));
                    }
                    r.Close();
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

        }



    }
}
