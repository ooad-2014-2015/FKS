﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOAD_FKS;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace Baza
{
    public partial class Dal
    {
        public class IgracDa : Interface< Igrac >
        {
            protected MySqlCommand command;
            public struct IgracP
            {
                
             
       public int igrac_id;
        public string ime   ;
        public string prezime;
        public DateTime datum_rodjenja ;
        public DateTime datum_registracije ;
        public int klub ;
        public bool suspenzija ;
        public int broj_zutih ;
        public int broj_crvenih ;
        public int broj_golova ;
        public int broj_asistenciaj;
        public string drzava ;
        public string jmbg ;



        public IgracP(string ime1, string prezime1, DateTime rod, int k, bool suspenzija1, int zuti, int crveni, int golovi, int ass, string drzava1, string jmbg1, DateTime? reg=null, int id = 0)
        {
            igrac_id=id;
            ime=ime1;
            prezime=prezime1;
            datum_rodjenja=rod;
            if (reg == null) datum_registracije = DateTime.Now;
            else datum_registracije = Convert.ToDateTime(reg);
          
            klub=k;
            suspenzija=suspenzija1;
            broj_zutih=zuti;
            broj_golova=golovi;
            broj_crvenih=crveni;
            broj_asistenciaj=ass;
            drzava=drzava1;
            jmbg=jmbg1;
           
        }
            }
            public Klub dajKlub(int id)
            {
                Baza.Dal d = Baza.Dal.instanca;
                d.kreirajKonekciju("localhost", "fks", "root", "Vela");

                Baza.Dal.KlubDa klub = d.getDAO.getKlubDa();
                Klub l = null;
                l = klub.getByld(id);

                d.terminirajKonekciju();
                return l;
            }
            public long create(Igrac entity)
            {
               
                try
                {
                    refreshConnection();
                    string query = "Insert into fks.igrac (ime,prezime,datum_rodjenja,klub_id,suspenzija,broj_zutih,broj_crvenih,broj_golova,broj_asistencija,drzava,jmbg,datum_registracije) values ('" + entity.ime + "','" + entity.prezime + "',date('" + entity.datum_rodjenja.ToString("yyyy.MM.dd") + "')," + entity.klub.klub_id + "," + Convert.ToInt32(entity.suspenzija) + "," + entity.broj_zutih + "," + entity.broj_crvenih + "," + entity.broj_golova + "," + entity.broj_asistenciaj + ",'" + entity.drzava + "','" + entity.jmbg + "',date('" + entity.datum_registracije.ToString("yyyy.MM.dd") + "')) ;";


                    command = new MySqlCommand(query, con);
                    command.ExecuteNonQuery();

                    return command.LastInsertedId;
                }
                catch (Exception e)
                {
                    throw e;
                }

            }


            public Igrac read(Igrac entity)
            {
                try
                {
                    refreshConnection();
                    string query = "Select * from fks.igrac where igrac_id='" + entity.igrac_id + "';";


                    command = new MySqlCommand(query, con);
                    List<Igrac> z = new List<Igrac>();
                    List<IgracP> pom = new List<IgracP>();
                    MySqlDataReader r = command.ExecuteReader();
                    while (r.Read())
                    {
                        pom.Add(new IgracP(r.GetString(0), r.GetString(1), r.GetDateTime(2), r.GetInt32(3), Convert.ToBoolean(r.GetInt32(4)), r.GetInt32(5), r.GetInt32(6), r.GetInt32(7), r.GetInt32(8), r.GetString(9), r.GetString(10), r.GetDateTime(11), r.GetInt32(12)));
                    }
                    r.Close();
                    foreach (IgracP p in pom)
                    {
                        z.Add(new Igrac(p.ime, p.prezime, p.datum_rodjenja, dajKlub(p.klub), p.suspenzija, p.broj_zutih, p.broj_crvenih, p.broj_golova, p.broj_asistenciaj, p.drzava, p.jmbg, p.datum_registracije, p.igrac_id));
                    }
                    return z[0];

                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public Igrac update(Igrac entity)
            {
                try
                {
                    refreshConnection();
                    string query = "update fks.igrac set ime ='" + entity.ime + "',prezime ='" + entity.prezime + "',datum_rodjenja = date('" + entity.datum_rodjenja.ToString("yyyy.MM.dd") + "'),klub_id =" + entity.klub.klub_id + ",suspenzija = " + Convert.ToInt32(entity.suspenzija) + ",broj_zutih =" + entity.broj_zutih + ",broj_crvanih =" + entity.broj_crvenih + ",broj_golova =" + entity.broj_golova + ",broj_asistencija =" + entity.broj_asistenciaj + ",drzava ='" + entity.drzava + "',jmbg ='" + entity.jmbg + "',datum_registracije = date('" + entity.datum_registracije.ToString("yyyy.MM.dd")  +"' where igrac_id = " + entity.igrac_id + ";";


                  


                    command = new MySqlCommand(query, con);

                    command.ExecuteNonQuery();

                    return entity;
                }
                catch (Exception)
                {
                    throw;
                }
            }


            public void delete(Igrac entity)
            {
                try
                {
                    Baza.Dal d = Baza.Dal.instanca;
                    d.kreirajKonekciju("localhost", "fks", "root", "Vela");
                    refreshConnection();
                    string query = "delete from fks.igrac where igrac_id= " + entity.igrac_id + ";";

                    
                    command = new MySqlCommand(query, d.dajKonekciju());

                    command.ExecuteNonQuery();
                    d.terminirajKonekciju();
                }
                catch (Exception)
                {

                    throw;
                }
            }

            public Igrac getByld(int  id )
            {
                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.igrac where igrac_id = " + id + " ;", con);
                    List<Igrac> z = new List<Igrac>();
                    List<IgracP> pom = new List<IgracP>();
                    MySqlDataReader r = command.ExecuteReader();
                    while (r.Read())
                    {
                        pom.Add(new IgracP(r.GetString(0), r.GetString(1), r.GetDateTime(2), r.GetInt32(3), Convert.ToBoolean(r.GetInt32(4)), r.GetInt32(5), r.GetInt32(6), r.GetInt32(7), r.GetInt32(8), r.GetString(9), r.GetString(10), r.GetDateTime(11), r.GetInt32(12)));
                    }
                    r.Close();
                    foreach (IgracP p in pom)
                    {
                        z.Add(new Igrac(p.ime, p.prezime, p.datum_rodjenja, dajKlub(p.klub), p.suspenzija, p.broj_zutih, p.broj_crvenih, p.broj_golova, p.broj_asistenciaj, p.drzava, p.jmbg, p.datum_registracije, p.igrac_id));
                    }
                    return z[0];
                }
                catch (Exception e)
                {
                    throw e;
                }

            }
            public List<Igrac> getAll()
            {

                try
                {
                    refreshConnection();
                    command = new MySqlCommand("select * from fks.igrac ;", con);
                    List<Igrac> z = new List<Igrac>();
                    List<IgracP> pom = new List<IgracP>();
                    MySqlDataReader r = command.ExecuteReader();
                    while (r.Read())
                    {
                        pom.Add(new IgracP(r.GetString(0), r.GetString(1), r.GetDateTime(2), r.GetInt32(3), Convert.ToBoolean(r.GetInt32(4)), r.GetInt32(5), r.GetInt32(6), r.GetInt32(7), r.GetInt32(8), r.GetString(9), r.GetString(10), r.GetDateTime(11), r.GetInt32(12)));
                    }
                    r.Close();
                    foreach (IgracP p in pom)
                    {
                        z.Add(new Igrac(p.ime, p.prezime, p.datum_rodjenja, dajKlub(p.klub), p.suspenzija, p.broj_zutih, p.broj_crvenih, p.broj_golova, p.broj_asistenciaj, p.drzava, p.jmbg, p.datum_registracije, p.igrac_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            public List<Igrac> getByExample(string name, string value)
            {
                try
                {
                    command = new MySqlCommand("select * from fks.igrac where '" + name + "'='" + value + "' ;", con);
                    List<Igrac> z = new List<Igrac>();
                    List<IgracP> pom = new List<IgracP>();
                    MySqlDataReader r = command.ExecuteReader();
                    while (r.Read())
                    {
                        pom.Add(new IgracP (r.GetString(0),r.GetString(1),r.GetDateTime(2),r.GetInt32(3),Convert.ToBoolean(r.GetInt32(4)),r.GetInt32(5),r.GetInt32(6),r.GetInt32(7),r.GetInt32(8),r.GetString(9),r.GetString(10),r.GetDateTime(11),r.GetInt32(12)));
                    }
                    r.Close();
                    foreach (IgracP p in pom)
                    {
                        z.Add(new Igrac(p.ime,p.prezime,p.datum_rodjenja,dajKlub(p.klub),p.suspenzija,p.broj_zutih,p.broj_crvenih,p.broj_golova,p.broj_asistenciaj,p.drzava,p.jmbg,p.datum_registracije,p.igrac_id));
                    }
                    return z;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }


        }



    }
}
