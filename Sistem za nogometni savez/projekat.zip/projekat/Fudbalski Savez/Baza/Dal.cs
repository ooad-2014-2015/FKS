﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
namespace Baza
{
    public partial class Dal
    {
        private static string _host = "localhost", _db = "fks", _user = "root", _pass = "Vela";
        private static MySqlConnection con = null;

        public MySqlConnection dajKonekciju()
        { return con; }
        private static Dal instanca = null;

        public static Dal Instanca
        {
            get { return (instanca == null) ? instanca = new Dal() : instanca; }
        }

        private Dal() { kreirajKonekciju(); }
        ~Dal() { terminirajKonekciju(); }

        public DAOFactory getDAO // mozemo napraviti i getDAO(tipBaze) koja vraca npr DAOMySqlFactory i sl. zavisi od potrebe
        {
            get { return DAOFactory.Instanca; }
        }

        public static void refreshConnection()
        {
            if (con != null)
            {
                disconnect();
                connect();
            }
        }

        public static void connect()
        {

            if (_host != "" && _db != "" && _user != "")
            {
                string connectionString = "server=localhost;user=" + _user + ";pwd=" + _pass + ";database=" + _db + ";Convert Zero Datetime=True;Allow Zero Datetime=True";
                con = new MySqlConnection(connectionString);
                try
                {
                    con.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }

        public static void disconnect()
        {
            try
            {
                if (con != null) 
                    con.Close();

                con = null;
            }
            catch (Exception e) { throw e; }
        }

        public void kreirajKonekciju(string host, string db, string user, string pass)
        {
            if (con != null) return;

            _host = host;
            _db = db;
            _user = user;
            _pass = pass;
            connect();

        }

        public void kreirajKonekciju()
        {
            if (con != null) return;
            connect();
        }



        public void terminirajKonekciju()
        {
            disconnect();
        }
    }
}
